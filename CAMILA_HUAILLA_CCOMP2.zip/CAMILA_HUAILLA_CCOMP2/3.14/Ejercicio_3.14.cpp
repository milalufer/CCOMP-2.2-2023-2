// Ejercicio_3.14.cpp : 
//
#include<iostream>
#include<string>
#include<D:\Camila Clases\Ejercicio_3.14\Header_3.14.h>

int main() {
    // Iniciar de Account 
    Account myAccount{ 50505, "Camila", "Lul", 1000.0 };

    // Mostrar la información de la cuenta
    cout << "Account Number: " << myAccount.getAccountNumber() << endl;
    cout << "Name: " << myAccount.getName() << endl;
    cout << "Balance: $" << myAccount.getBalance() << endl;

    return 0;
}