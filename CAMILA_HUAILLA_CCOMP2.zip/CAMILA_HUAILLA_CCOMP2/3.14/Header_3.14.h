#include<iostream>
#include<string>
using namespace std;

class Account {
public:
    Account(unsigned int accNumber, string fName, string lName, double initBalance) ///unsigned int, dos strings y un double reemplzar
        : accountNumber{ accNumber }, firstName{ fName }, lastName{ lName }, balance{ initBalance } {}

    void deposit(double depositAmount) {
        if (depositAmount > 0) {
            balance += depositAmount;
        }
    }

    double getBalance() const {
        return balance;
    }

    void setName(string fName, string lName) {
        firstName = fName;
        lastName = lName;
    }

    string getName() const {
        return firstName + " " + lastName;
    }

    void withdraw(double withdrawAmount) {
        if (withdrawAmount <= balance) {
            balance -= withdrawAmount;
        }
        else {
            cout << "Withdrawal amount exceeds account balance." << endl;
        }
    }

    unsigned int getAccountNumber() const {
        return accountNumber;
    }

private:
    unsigned int accountNumber;
    string firstName;
    string lastName;
    double balance{ 0.0 };
};
