#pragma once
#include <iostream>
#include <string>

class MotorVehicle {
public:
    MotorVehicle(const std::string& marca, const std::string& Combustible, int AnioManufactura, const std::string& color, int Capacidad)
        : marca_(marca), Combustible_(Combustible), AnioManufactura_(AnioManufactura), color_(color), Capacidad_(Capacidad) {}

    // Funciones setter
    void setMarca(const std::string& marca) {
        marca_ = marca;
    }

    void setCombustible(const std::string& Combustible) {
        Combustible_ = Combustible;
    }

    void setAnioManufactura(int AnioManufactura) {
        AnioManufactura_ = AnioManufactura;
    }

    void setColor(const std::string& color) {
        color_ = color;
    }

    void setCapacidad(int Capacidad) {
        Capacidad_ = Capacidad;
    }

    // Funciones
    std::string getMarca() const {
        return marca_;
    }

    std::string getCombustible() const {
        return Combustible_;
    }

    int getAnioManufactura() const {
        return AnioManufactura_;
    }

    std::string getColor() const {
        return color_;
    }

    int getCapacidad() const {
        return Capacidad_;
    }

    // Funci�n para mostrar los detalles del veh�culo
    void MostrarDetallesCarro() const {
        std::cout << "Marca: " << marca_ << std::endl;
        std::cout << "Combustible: " << Combustible_ << std::endl;
        std::cout << "A�o de Manufactura: " << AnioManufactura_ << std::endl;
        std::cout << "Color: " << color_ << std::endl;
        std::cout << "Capacidad del motor: " << Capacidad_ << std::endl;
    }

private:
    std::string marca_;
    std::string Combustible_;
    int AnioManufactura_;
    std::string color_;
    int Capacidad_;
};

