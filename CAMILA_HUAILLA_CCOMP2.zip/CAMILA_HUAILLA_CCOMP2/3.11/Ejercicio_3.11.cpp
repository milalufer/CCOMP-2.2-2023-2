// Ejercicio_3.11.cpp 

#include <iostream>
#include <D:\Camila Clases\Ejercicio_3.11\Header3_3.11.hpp>
int main() {
    // Crear un objeto MotorVehicle
    MotorVehicle miAuto("Toyota", "Gasolina", 2022, "Azul", 2000);

    // Mostrar los detalles del vehículo
    std::cout << "Detalles del auto:" << std::endl;
    miAuto.MostrarDetallesCarro();

    // Cambiar la marca del vehículo usando el setter
    miAuto.setMarca("Honda");

    return 0;
}
