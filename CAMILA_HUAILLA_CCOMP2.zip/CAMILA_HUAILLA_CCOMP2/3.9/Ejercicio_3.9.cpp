// Ejercicio_3.9.cpp 
#include <string>
#include <iostream>
#include <D:\Camila Clases\Ejercicio_3.9\Clases1.hpp>

int main() {
    Cuenta MiCuenta("Camila Lujan", 1000.0);

    MiCuenta.deposito(1500.0);

    MiCuenta.retiro(20000.0);


    return 0;
}

