#pragma once
#include <string>
#include <iostream>

class Cuenta {
public:
    Cuenta(std::string NombreCuenta, int BalanceInicial)
        : Nombre(NombreCuenta), balance(BalanceInicial >= 0.0 ? BalanceInicial : 0.0) {
        if (BalanceInicial < 0) {
            balance = BalanceInicial;
        }
    }

    void deposito(int MontoDepositado) {
        if (MontoDepositado > 0) {
            balance += MontoDepositado;
        }
    }

    void retiro(double RetirarMonto) {
        if (RetirarMonto > balance) {
            std::cout << "El monto del retiro excedio el saldo de la cuenta" << std::endl;
        } else {
            balance = balance - RetirarMonto;
        }
    }

    int obtenerBalance() const {
        return balance;
    }

private:
    std::string Nombre;
    double balance;
};




