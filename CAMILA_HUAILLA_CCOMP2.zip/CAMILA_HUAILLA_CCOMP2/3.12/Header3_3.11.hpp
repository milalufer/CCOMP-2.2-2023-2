#include <iostream>

class Fecha {
public:
    // Constructor de tres parametros:
    Fecha (int mes, int dia, int anio) {
        setmes(mes);
        setdia(dia);
        setanio(anio);
    }

    // Funciones 
    void setmes(int mes) {
        if (mes >= 1 && mes <= 12) {
            mes_ = mes;
        }
        else { // Si el valor de mes no est� en el rango v�lido, establecerlo en 1 (enero)
            mes_ = 1;
        }
    }

    void setdia(int dia) {
        dia_ = dia;
    }

    void setanio(int anio) {
        anio_ = anio;
    }

    int getmes() const {
        return mes_;
    }

    int getdia() const {
        return dia_;
    }

    int getanio() const {
        return anio_;
    }

    // Funci�n para mostrar la fecha en formato mes/d�a/a�o
    void MostrarFecha() const {
        std::cout << getmes() << "/" << getdia() << "/" << getanio() << std::endl;
    }

private:
    int mes_;
    int dia_;
    int anio_;
};

