// Ejercicio_3.12.cpp 
#include <iostream>
#include <D:\Camila Clases\Ejercicio_3.12\Header3_3.11.hpp>

int main() {
    // Crear un objeto Date con una fecha válida
    Fecha MiFecha(9, 12, 2023);

    // Mostrar la fecha
    std::cout << "Fecha: ";
    MiFecha.MostrarFecha();

    // Cambiar la fecha usando los setters
    MiFecha.setmes(11);
    MiFecha.setdia(25);
    MiFecha.setanio(2024);

    // Mostrar la fecha actualizada
    std::cout << "Fecha actualizada: ";
    MiFecha.MostrarFecha();

    return 0;
}