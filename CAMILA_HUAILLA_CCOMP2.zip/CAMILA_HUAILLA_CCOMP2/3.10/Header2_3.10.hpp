#pragma once
#include <string>

#include <string>

class Factura {
public:
    // Constructor 
    Factura(std::string pn = "", std::string des = "", int qt = 0, int pr = 0, double vx = 0.2, double dc = 0)
        : partNumero(pn), Descripcion(des), cuantificador(qt), precio(pr), vax(vx), descuento(dc) {}

    void setPartNumero(std::string pn) {
        partNumero = pn;
    }

    void setDescripcion(std::string des) {
        Descripcion = des;
    }

    void setCuantificador(int qt) {
        if (qt > 0) {
            cuantificador = qt;
        }
    }

    void setPrecio(int pr) {
        if (pr > 0) {
            precio = pr;
        }
    }

    void setVax(double vx) {
        if (vx > 0) {
            vax = vx;
        }
    }

    void setDescuento(double dc) {
        if (dc > 0) {
            descuento = dc;
        }
    }
    //obtener
    std::string getPartNumero() const {
        return partNumero;
    }

    std::string getDescripcion() const {
        return Descripcion;
    }

    int getCuantificador() const {
        return cuantificador;
    }

    int getPrecio() const {
        return precio;
    }

    double getVax() const {
        return vax;
    }

    double getDescuento() const {
        return descuento;
    }

    double getCuentaFactura() const {
        return cuantificador * precio;
    }

private:
    std::string partNumero;
    std::string Descripcion;
    int cuantificador;
    int precio;
    double vax;
    double descuento;
};

