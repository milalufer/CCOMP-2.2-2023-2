// Ejercicio_3.10.cpp 

#include <iostream>
#include <string>
#include "D:\Camila Clases\Ejercicio_3.10\Header2_3.10.hpp" 

using namespace std;

int main() {
    // Variables 
    string numeroParte, descripcion;
    int cantidad, precioUnitario;
    double impuesto, descuento;

    cout << "Ingrese el numero de pieza: ";
    cin >> numeroParte;

    cout << "Ingrese la descripcion: ";
    cin.ignore(); 
    getline(cin, descripcion);

    cout << "Ingrese la cantidad: ";
    cin >> cantidad;

    cout << "Ingrese el precio unitario: ";
    cin >> precioUnitario;

    cout << "Ingrese el impuesto (porcentaje): ";
    cin >> impuesto;

    cout << "Ingrese el descuento (porcentaje): ";
    cin >> descuento;

    // Objeto Factura 
    Factura factura(numeroParte, descripcion, cantidad, precioUnitario, impuesto / 100, descuento / 100);

    // Calcular el monto total de la factura
    double total = factura.getCuentaFactura();

    // Mostrar factura y el monto total
    cout << "\nDetalles de la factura:\n";
    cout << "Numero de parte: " << factura.getPartNumero() << endl;
    cout << "Descripcion: " << factura.getDescripcion() << endl;
    cout << "Cantidad: " << factura.getCuantificador() << endl;
    cout << "Precio unitario: $" << factura.getPrecio() << endl;
    cout << "Impuesto: " << factura.getVax() * 100 << "%\n";
    cout << "Descuento: " << factura.getDescuento() * 100 << "%\n";
    cout << "Monto total de la factura: $" << total << endl;

    return 0;
}
