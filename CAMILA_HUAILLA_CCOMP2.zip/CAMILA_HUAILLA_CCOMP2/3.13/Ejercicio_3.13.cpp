// Ejercicio_3.13.cpp 
#include <iostream>
#include "D:\Camila Clases\Ejercicio_3.13\Header3_3.13.h"
using namespace std;

void displayAccount(Account accountToDisplay) {
    cout << "Account: " << accountToDisplay.getName() << " balance es:" << accountToDisplay.getBalance() << endl;
}

int main() {
    Account account1{ "Camila Fernandez", 100 };
    Account account2{ "Yanela Lujan", 500 };
    displayAccount(account1);
    displayAccount(account2);

    cout << "\n\nIngresa el deposito para account1: ";
    int depositAmount;
    cin >> depositAmount;
    account1.deposit(depositAmount);

    displayAccount(account1);
    displayAccount(account2);

    cout << "\n\nIngresa el deposito para account2: ";
    cin >> depositAmount;
    account2.deposit(depositAmount);

    displayAccount(account1);
    displayAccount(account2);

    cout << "\n\nCuanto quieres retirar de account1?: ";
    int with_draw_cash;
    cin >> with_draw_cash;
    account1.withdraw(with_draw_cash);

    cout << "\n\nCuanto quieres retirar de account2?: ";
    cin >> with_draw_cash;
    account2.withdraw(with_draw_cash);

    displayAccount(account1);
    displayAccount(account2);

    return 0;
}



