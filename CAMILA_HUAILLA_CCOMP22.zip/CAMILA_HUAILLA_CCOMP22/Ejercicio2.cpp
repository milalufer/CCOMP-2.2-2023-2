// Ejercicio2.cpp 
//número perfecto es igual a la suma de sus divisores, excluyendo a sí mismo.

#include <iostream>

using namespace std;

bool numPerfect(int num) {
    int sumDivisores = 1;

    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0) {
            sumDivisores += i;
            if (i != num / i) {
                sumDivisores += num / i;
            }
        }
    }

    return sumDivisores == num;
}

int main() {
    int n;
    cout << "Ingrese un numero n: ";
    cin >> n;

    int numero = 2;
    int encontrados = 0;

    cout << "Los primeros " << n << " numeros perfectos son: ";

    while (encontrados < n) {
        if (numPerfect(numero)) {
            cout << numero << " ";
            encontrados++;
        }
        numero++;
    }

    cout << endl;

    return 0;
}
