// Ejercicio3.cpp 
#include <iostream>

using namespace std;

int main() {
    int n;
    cout << "Ingrese un número n: ";
    cin >> n;

    int a = 1, b = 1;

    cout << "Los primeros " << n << " números de Fibonacci son: ";

    if (n >= 1) {
        cout << a << " ";
    }
    if (n >= 2) {
        cout << b << " ";
    }

    for (int i = 3; i <= n; i++) {
        int c = a + b;
        cout << c << " ";
        a = b;
        b = c;
    }

    cout << endl;

    return 0;
}
