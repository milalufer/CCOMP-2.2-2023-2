// Ejercicio1.cpp
#include <iostream>

using namespace std;

// Función para verificar si un número es primo
bool Primo(int numero) {
    if (numero <= 1) {
        return false;
    }
    for (int i = 2; i * i <= numero; i++) {
        if (numero % i == 0) {
            return false;
        }
    }
    return true;
}

int main() {
    int n;
    cout << "Ingrese un número n: ";
    cin >> n;

    if (n <= 0) {
        cout << "El número debe ser mayor que cero." << endl;
        return 1; // Salir del programa con un código de error
    }

    int contador = 0;
    int numero = 2; // Comenzamos desde el primer número primo (2)

    cout << "Los primeros " << n << " números primos son: ";

    while (contador < n) {
        if (Primo(numero)) {
            cout << numero << " ";
            contador++;
        }
        numero++;
    }

    cout << endl;

    return 0;
}

